package com.focusflow.focusflow.controller;

import com.focusflow.focusflow.model.Task;
import com.focusflow.focusflow.repository.TaskRepository;
import com.focusflow.focusflow.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/dashboard")
@CrossOrigin(origins = "http://localhost:3000")
public class DashboardController {

    private final TaskRepository taskRepository;
    private final UserRepository userRepository;

    public DashboardController(TaskRepository taskRepository, UserRepository userRepository) {
        this.taskRepository = taskRepository;
        this.userRepository = userRepository;
    }

    // GET /api/dashboard — summary stats for the logged-in user
    @GetMapping
    public ResponseEntity<?> getDashboard(Authentication auth) {
        String email = auth.getName();
        com.focusflow.focusflow.model.User User = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        List<Task> allTasks = taskRepository.findByUserId(User.getId());
        LocalDate today = LocalDate.now();
        LocalDate nextWeek = today.plusDays(7);

        List<Task> upcoming = allTasks.stream()
                .filter(t -> t.getDueDate() != null
                        && !t.getDueDate().isBefore(today)
                        && !t.getDueDate().isAfter(nextWeek)
                        && !t.isCompleted())
                .collect(Collectors.toList());

        List<Task> overdue = allTasks.stream()
                .filter(t -> t.getDueDate() != null
                        && t.getDueDate().isBefore(today)
                        && !t.isCompleted())
                .collect(Collectors.toList());

        long completed = allTasks.stream().filter(Task::isCompleted).count();
        long total = allTasks.size();

        return ResponseEntity.ok(Map.of(
                "totalTasks", total,
                "completedTasks", completed,
                "pendingTasks", total - completed,
                "upcomingDeadlines", upcoming,
                "overdueTasks", overdue
        ));
    }
}
