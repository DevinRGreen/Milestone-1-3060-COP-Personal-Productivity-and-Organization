package com.focusflow.focusflow.controller;

import com.focusflow.focusflow.model.Task;
import com.focusflow.focusflow.model.User;
import com.focusflow.focusflow.repository.TaskRepository;
import com.focusflow.focusflow.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/tasks")
@CrossOrigin(origins = "http://localhost:3000")
public class TaskController {

    private final TaskRepository taskRepository;
    private final UserRepository userRepository;

    public TaskController(TaskRepository taskRepository, UserRepository userRepository) {
        this.taskRepository = taskRepository;
        this.userRepository = userRepository;
    }

    // GET /api/tasks — get all tasks for logged-in user
    @GetMapping
    public ResponseEntity<List<Task>> getAllTasks(Authentication auth) {
        User user = getUser(auth);
        return ResponseEntity.ok(taskRepository.findByUserId(user.getId()));
    }

    // GET /api/tasks/{id} — get one task
    @GetMapping("/{id}")
    public ResponseEntity<?> getTask(@PathVariable Long id, Authentication auth) {
        User user = getUser(auth);
        Optional<Task> taskOpt = taskRepository.findById(id);

        if (taskOpt.isEmpty() || !taskOpt.get().getUser().getId().equals(user.getId())) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Task not found"));
        }

        return ResponseEntity.ok(taskOpt.get());
    }

    // POST /api/tasks — create a new task
    @PostMapping
    public ResponseEntity<Task> createTask(@RequestBody Task task, Authentication auth) {
        User user = getUser(auth);
        task.setUser(user);
        Task saved = taskRepository.save(task);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    // PUT /api/tasks/{id} — update a task
    @PutMapping("/{id}")
    public ResponseEntity<?> updateTask(@PathVariable Long id,
                                         @RequestBody Task updated,
                                         Authentication auth) {
        User user = getUser(auth);
        Optional<Task> taskOpt = taskRepository.findById(id);

        if (taskOpt.isEmpty() || !taskOpt.get().getUser().getId().equals(user.getId())) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Task not found"));
        }

        Task task = taskOpt.get();
        if (updated.getTitle() != null)       task.setTitle(updated.getTitle());
        if (updated.getDescription() != null) task.setDescription(updated.getDescription());
        if (updated.getCategory() != null)    task.setCategory(updated.getCategory());
        if (updated.getPriority() != null)    task.setPriority(updated.getPriority());
        if (updated.getDueDate() != null)     task.setDueDate(updated.getDueDate());
        task.setCompleted(updated.isCompleted());

        return ResponseEntity.ok(taskRepository.save(task));
    }

    // DELETE /api/tasks/{id} — delete a task
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTask(@PathVariable Long id, Authentication auth) {
        User user = getUser(auth);
        Optional<Task> taskOpt = taskRepository.findById(id);

        if (taskOpt.isEmpty() || !taskOpt.get().getUser().getId().equals(user.getId())) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Task not found"));
        }

        taskRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    // Helper: get current logged-in user from JWT
    private User getUser(Authentication auth) {
        String email = auth.getName();
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }
}
