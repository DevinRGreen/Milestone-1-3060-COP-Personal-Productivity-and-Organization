package com.focusflow.focusflow.repository;

import com.focusflow.focusflow.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<com.focusflow.focusflow.model.User> findByEmail(String email);
    boolean existsByEmail(String email);
}
