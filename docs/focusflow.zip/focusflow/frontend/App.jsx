import { useState, useEffect } from "react";
import Login from "./components/Login";
import Register from "./components/Register";
import Dashboard from "./components/Dashboard";
import Tasks from "./components/Tasks";
import Navbar from "./components/Navbar";
import "./App.css";

export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState("login");

  useEffect(() => {
    const saved = localStorage.getItem("focusflow_user");
    if (saved) {
      setUser(JSON.parse(saved));
      setPage("dashboard");
    }
  }, []);

  const handleLogin = (userData) => {
    localStorage.setItem("focusflow_user", JSON.stringify(userData));
    setUser(userData);
    setPage("dashboard");
  };

  const handleLogout = () => {
    localStorage.removeItem("focusflow_user");
    setUser(null);
    setPage("login");
  };

  if (!user) {
    return (
      <div className="auth-wrapper">
        {page === "login" ? (
          <Login onLogin={handleLogin} onSwitch={() => setPage("register")} />
        ) : (
          <Register onRegister={() => setPage("login")} onSwitch={() => setPage("login")} />
        )}
      </div>
    );
  }

  return (
    <div className="app">
      <Navbar user={user} onLogout={handleLogout} onNavigate={setPage} currentPage={page} />
      <main className="main-content">
        {page === "dashboard" && <Dashboard user={user} />}
        {page === "tasks" && <Tasks user={user} />}
      </main>
    </div>
  );
}
