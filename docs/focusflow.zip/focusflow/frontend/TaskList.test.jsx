import React from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";

// Minimal TaskList component inline for testing
// (replace with: import TaskList from "../components/TaskList" once extracted)
function TaskList({ tasks }) {
  if (!tasks || tasks.length === 0) {
    return <p>No tasks yet</p>;
  }
  return (
    <ul>
      {tasks.map((task) => (
        <li key={task.id}>
          <strong>{task.title}</strong>
          <span>{task.category}</span>
          <span>{task.priority}</span>
        </li>
      ))}
    </ul>
  );
}

const mockTasks = [
  { id: 1, title: "Study for exam", category: "school", priority: "HIGH" },
  { id: 2, title: "Submit work report", category: "work", priority: "MEDIUM" },
];

describe("TaskList Component", () => {

  // TEST 1: Renders task titles
  test("renders task titles from props", () => {
    render(<TaskList tasks={mockTasks} />);
    expect(screen.getByText("Study for exam")).toBeInTheDocument();
    expect(screen.getByText("Submit work report")).toBeInTheDocument();
  });

  // TEST 2: Shows empty state when no tasks
  test("shows empty message when no tasks provided", () => {
    render(<TaskList tasks={[]} />);
    expect(screen.getByText(/no tasks yet/i)).toBeInTheDocument();
  });

  // TEST 3: Displays category and priority labels
  test("displays category and priority for each task", () => {
    render(<TaskList tasks={mockTasks} />);
    expect(screen.getByText("school")).toBeInTheDocument();
    expect(screen.getByText("HIGH")).toBeInTheDocument();
  });
});
