import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom";
import Login from "../components/Login";

// Mock the api module
jest.mock("../api", () => ({
  login: jest.fn(),
}));

import { login } from "../api";

describe("Login Component", () => {

  beforeEach(() => {
    jest.clearAllMocks();
  });

  // TEST 1: Renders email and password fields
  test("renders email and password input fields", () => {
    render(<Login onLogin={jest.fn()} onSwitch={jest.fn()} />);
    expect(screen.getByLabelText(/email/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/password/i)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /login/i })).toBeInTheDocument();
  });

  // TEST 2: Shows error when submitted empty
  test("shows error message when submitted with empty email", async () => {
    render(<Login onLogin={jest.fn()} onSwitch={jest.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: /login/i }));
    await waitFor(() => {
      expect(screen.getByText(/email is required/i)).toBeInTheDocument();
    });
  });

  // TEST 3: Calls onLogin with correct values on valid submit
  test("calls onLogin handler with user data on successful login", async () => {
    const mockUser = { id: 1, name: "Jane", email: "jane@test.com", token: "abc123" };
    login.mockResolvedValueOnce(mockUser);

    const mockOnLogin = jest.fn();
    render(<Login onLogin={mockOnLogin} onSwitch={jest.fn()} />);

    fireEvent.change(screen.getByLabelText(/email/i), { target: { value: "jane@test.com" } });
    fireEvent.change(screen.getByLabelText(/password/i), { target: { value: "password123" } });
    fireEvent.click(screen.getByRole("button", { name: /login/i }));

    await waitFor(() => {
      expect(mockOnLogin).toHaveBeenCalledWith(mockUser);
    });
  });
});
