const BASE_URL = "http://localhost:8080/api";

function getToken() {
  const user = JSON.parse(localStorage.getItem("focusflow_user") || "{}");
  return user.token || "";
}

export async function apiRequest(path, method = "GET", body = null) {
  const headers = {
    "Content-Type": "application/json",
    Authorization: `Bearer ${getToken()}`,
  };

  const options = { method, headers };
  if (body) options.body = JSON.stringify(body);

  const res = await fetch(`${BASE_URL}${path}`, options);
  const data = await res.json().catch(() => null);

  if (!res.ok) throw new Error(data?.error || "Request failed");
  return data;
}

// Auth
export const register = (name, email, password) =>
  apiRequest("/auth/register", "POST", { name, email, password });

export const login = (email, password) =>
  apiRequest("/auth/login", "POST", { email, password });

// Tasks
export const getTasks = () => apiRequest("/tasks");
export const getTask = (id) => apiRequest(`/tasks/${id}`);
export const createTask = (task) => apiRequest("/tasks", "POST", task);
export const updateTask = (id, task) => apiRequest(`/tasks/${id}`, "PUT", task);
export const deleteTask = (id) => apiRequest(`/tasks/${id}`, "DELETE");

// Dashboard
export const getDashboard = () => apiRequest("/dashboard");
