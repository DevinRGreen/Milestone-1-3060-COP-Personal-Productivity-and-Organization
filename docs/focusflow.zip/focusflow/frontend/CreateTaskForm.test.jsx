import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom";
import CreateTaskForm from "../components/CreateTaskForm";

describe("CreateTaskForm Component", () => {

  // TEST 1: Renders all form fields
  test("renders title, category, priority, and due date fields", () => {
    render(<CreateTaskForm onSubmit={jest.fn()} onCancel={jest.fn()} />);
    expect(screen.getByLabelText(/task title/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/category/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/priority/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/due date/i)).toBeInTheDocument();
  });

  // TEST 2: Input field updates state on change
  test("updates task title input value on change", () => {
    render(<CreateTaskForm onSubmit={jest.fn()} onCancel={jest.fn()} />);
    const titleInput = screen.getByLabelText(/task title/i);
    fireEvent.change(titleInput, { target: { value: "Finish assignment" } });
    expect(titleInput.value).toBe("Finish assignment");
  });

  // TEST 3: Calls onSubmit with correct task data
  test("calls onSubmit with form data on valid submit", async () => {
    const mockSubmit = jest.fn();
    render(<CreateTaskForm onSubmit={mockSubmit} onCancel={jest.fn()} />);

    fireEvent.change(screen.getByLabelText(/task title/i), {
      target: { value: "Complete project" },
    });
    fireEvent.change(screen.getByLabelText(/category/i), {
      target: { value: "school" },
    });
    fireEvent.change(screen.getByLabelText(/priority/i), {
      target: { value: "HIGH" },
    });

    fireEvent.click(screen.getByRole("button", { name: /create task/i }));

    await waitFor(() => {
      expect(mockSubmit).toHaveBeenCalledWith(
        expect.objectContaining({
          title: "Complete project",
          category: "school",
          priority: "HIGH",
        })
      );
    });
  });
});
