import { useEffect, useState } from "react";
import { getDashboard } from "../api";

export default function Dashboard({ user }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getDashboard()
      .then(setData)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="loading">Loading dashboard...</div>;

  return (
    <div className="dashboard">
      <h1>Welcome back, {user.name} 👋</h1>
      <p className="dash-sub">Here's your productivity overview</p>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-number">{data?.totalTasks ?? 0}</div>
          <div className="stat-label">Total Tasks</div>
        </div>
        <div className="stat-card green">
          <div className="stat-number">{data?.completedTasks ?? 0}</div>
          <div className="stat-label">Completed</div>
        </div>
        <div className="stat-card yellow">
          <div className="stat-number">{data?.pendingTasks ?? 0}</div>
          <div className="stat-label">Pending</div>
        </div>
        <div className="stat-card red">
          <div className="stat-number">{data?.overdueTasks?.length ?? 0}</div>
          <div className="stat-label">Overdue</div>
        </div>
      </div>

      <section className="dash-section">
        <h2>📅 Due This Week</h2>
        {data?.upcomingDeadlines?.length === 0 ? (
          <p className="empty-msg">No upcoming deadlines — you're all caught up!</p>
        ) : (
          <ul className="task-list">
            {data?.upcomingDeadlines?.map((task) => (
              <li key={task.id} className="task-item">
                <div className="task-title">{task.title}</div>
                <div className="task-meta">
                  <span className={`badge ${task.priority?.toLowerCase()}`}>{task.priority}</span>
                  <span className="badge category">{task.category}</span>
                  <span className="due-date">Due: {task.dueDate}</span>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="dash-section">
        <h2>⚠️ Overdue Tasks</h2>
        {data?.overdueTasks?.length === 0 ? (
          <p className="empty-msg">No overdue tasks!</p>
        ) : (
          <ul className="task-list">
            {data?.overdueTasks?.map((task) => (
              <li key={task.id} className="task-item overdue">
                <div className="task-title">{task.title}</div>
                <span className="due-date">Was due: {task.dueDate}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
