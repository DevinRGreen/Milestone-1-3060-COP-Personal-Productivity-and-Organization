import { useEffect, useState } from "react";
import { getTasks, createTask, updateTask, deleteTask } from "../api";
import CreateTaskForm from "./CreateTaskForm";

export default function Tasks() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [filter, setFilter] = useState("all");

  const load = () => {
    getTasks()
      .then(setTasks)
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const handleCreate = async (taskData) => {
    await createTask(taskData);
    setShowForm(false);
    load();
  };

  const handleUpdate = async (taskData) => {
    await updateTask(editingTask.id, taskData);
    setEditingTask(null);
    load();
  };

  const handleDelete = async (id) => {
    if (window.confirm("Delete this task?")) {
      await deleteTask(id);
      load();
    }
  };

  const handleToggleComplete = async (task) => {
    await updateTask(task.id, { ...task, completed: !task.completed });
    load();
  };

  const filtered = filter === "all"
    ? tasks
    : tasks.filter((t) => t.category === filter);

  if (loading) return <div className="loading">Loading tasks...</div>;

  return (
    <div className="tasks-page">
      <div className="tasks-header">
        <h1>My Tasks</h1>
        <button className="btn-primary" onClick={() => { setShowForm(true); setEditingTask(null); }}>
          + New Task
        </button>
      </div>

      {/* Category Filter */}
      <div className="filter-bar">
        {["all", "school", "work", "personal"].map((cat) => (
          <button
            key={cat}
            className={`filter-btn ${filter === cat ? "active" : ""}`}
            onClick={() => setFilter(cat)}
          >
            {cat.charAt(0).toUpperCase() + cat.slice(1)}
          </button>
        ))}
      </div>

      {/* Create / Edit Form */}
      {(showForm || editingTask) && (
        <CreateTaskForm
          initial={editingTask}
          onSubmit={editingTask ? handleUpdate : handleCreate}
          onCancel={() => { setShowForm(false); setEditingTask(null); }}
        />
      )}

      {/* Task List */}
      {filtered.length === 0 ? (
        <div className="empty-state">
          <p>No tasks yet — create one above!</p>
        </div>
      ) : (
        <ul className="task-list">
          {filtered.map((task) => (
            <li key={task.id} className={`task-item ${task.completed ? "completed" : ""}`}>
              <input
                type="checkbox"
                checked={task.completed}
                onChange={() => handleToggleComplete(task)}
                aria-label={`Mark ${task.title} as complete`}
              />
              <div className="task-info">
                <div className="task-title">{task.title}</div>
                {task.description && <div className="task-desc">{task.description}</div>}
                <div className="task-meta">
                  <span className={`badge ${task.priority?.toLowerCase()}`}>{task.priority}</span>
                  <span className="badge category">{task.category}</span>
                  {task.dueDate && <span className="due-date">📅 {task.dueDate}</span>}
                </div>
              </div>
              <div className="task-actions">
                <button className="btn-edit" onClick={() => { setEditingTask(task); setShowForm(false); }}>
                  Edit
                </button>
                <button className="btn-delete" onClick={() => handleDelete(task.id)}>
                  Delete
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
