export default function Navbar({ user, onLogout, onNavigate, currentPage }) {
  return (
    <nav className="navbar">
      <div className="nav-logo">✅ FocusFlow</div>
      <div className="nav-links">
        <button
          className={`nav-btn ${currentPage === "dashboard" ? "active" : ""}`}
          onClick={() => onNavigate("dashboard")}
        >
          Dashboard
        </button>
        <button
          className={`nav-btn ${currentPage === "tasks" ? "active" : ""}`}
          onClick={() => onNavigate("tasks")}
        >
          My Tasks
        </button>
      </div>
      <div className="nav-user">
        <span>Hi, {user.name}</span>
        <button className="btn-logout" onClick={onLogout}>Logout</button>
      </div>
    </nav>
  );
}
