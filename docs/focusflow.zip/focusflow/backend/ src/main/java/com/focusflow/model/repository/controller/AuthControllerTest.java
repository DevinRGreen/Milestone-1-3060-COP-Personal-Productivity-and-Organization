package com.focusflow.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Map;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class AuthControllerTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private ObjectMapper objectMapper;

    // TEST 1: Register a new user successfully
    @Test
    @Order(1)
    public void testRegisterUser_Success() throws Exception {
        Map<String, String> body = Map.of(
                "name", "Test User",
                "email", "testuser@focusflow.com",
                "password", "SecurePass123!"
        );

        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(body)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.email").value("testuser@focusflow.com"))
                .andExpect(jsonPath("$.name").value("Test User"));
    }

    // TEST 2: Duplicate email returns 409 Conflict
    @Test
    @Order(2)
    public void testRegisterUser_DuplicateEmail_Returns409() throws Exception {
        Map<String, String> body = Map.of(
                "name", "Test User",
                "email", "testuser@focusflow.com", // same email as test 1
                "password", "AnotherPass456!"
        );

        mockMvc.perform(post("/api/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(body)))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.error").value("Email already in use"));
    }

    // TEST 3: Login with valid credentials returns JWT token
    @Test
    @Order(3)
    public void testLogin_ValidCredentials_ReturnsToken() throws Exception {
        Map<String, String> body = Map.of(
                "email", "testuser@focusflow.com",
                "password", "SecurePass123!"
        );

        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(body)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").exists())
                .andExpect(jsonPath("$.email").value("testuser@focusflow.com"));
    }

    // TEST 4: Login with wrong password returns 401
    @Test
    @Order(4)
    public void testLogin_WrongPassword_Returns401() throws Exception {
        Map<String, String> body = Map.of(
                "email", "testuser@focusflow.com",
                "password", "WrongPassword!"
        );

        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(body)))
                .andExpect(status().isUnauthorized());
    }
}
