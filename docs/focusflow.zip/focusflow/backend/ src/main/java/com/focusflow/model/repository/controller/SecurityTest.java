package com.focusflow.security;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class SecurityTest {

    @Autowired private MockMvc mockMvc;

    // TEST 1: No token -> 401
    @Test
    public void testNoToken_Returns401() throws Exception {
        mockMvc.perform(get("/api/tasks"))
                .andExpect(status().isUnauthorized());
    }

    // TEST 2: Invalid token -> 401
    @Test
    public void testInvalidToken_Returns401() throws Exception {
        mockMvc.perform(get("/api/tasks")
                .header("Authorization", "Bearer this.is.not.valid"))
                .andExpect(status().isUnauthorized());
    }

    // TEST 3: Auth endpoints are public (no token needed)
    @Test
    public void testAuthEndpoint_IsPublic() throws Exception {
        mockMvc.perform(get("/api/auth/register"))
                .andExpect(status().is(org.hamcrest.Matchers.not(401)));
    }
}
