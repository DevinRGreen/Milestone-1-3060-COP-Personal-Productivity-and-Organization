package com.focusflow.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.focusflow.model.User;
import com.focusflow.repository.UserRepository;
import com.focusflow.security.JwtUtil;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Map;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TaskControllerTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private ObjectMapper objectMapper;
    @Autowired private UserRepository userRepository;
    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private JwtUtil jwtUtil;

    private static String token;
    private static Long taskId;

    @BeforeEach
    public void setup() {
        // Create test user if not exists
        if (!userRepository.existsByEmail("tasktest@focusflow.com")) {
            User user = new User("Task Tester", "tasktest@focusflow.com",
                    passwordEncoder.encode("testpass123"));
            userRepository.save(user);
        }
        token = "Bearer " + jwtUtil.generateToken("tasktest@focusflow.com");
    }

    // TEST 1: Create a task
    @Test
    @Order(1)
    public void testCreateTask() throws Exception {
        Map<String, String> body = Map.of(
                "title", "Study for finals",
                "category", "school",
                "priority", "HIGH",
                "dueDate", "2025-05-15"
        );

        String response = mockMvc.perform(post("/api/tasks")
                .header("Authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(body)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.title").value("Study for finals"))
                .andExpect(jsonPath("$.category").value("school"))
                .andReturn().getResponse().getContentAsString();

        taskId = objectMapper.readTree(response).get("id").asLong();
    }

    // TEST 2: Get all tasks
    @Test
    @Order(2)
    public void testGetAllTasks() throws Exception {
        mockMvc.perform(get("/api/tasks")
                .header("Authorization", token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());
    }

    // TEST 3: Get one task by ID
    @Test
    @Order(3)
    public void testGetTaskById() throws Exception {
        mockMvc.perform(get("/api/tasks/" + taskId)
                .header("Authorization", token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Study for finals"));
    }

    // TEST 4: Update a task
    @Test
    @Order(4)
    public void testUpdateTask() throws Exception {
        Map<String, Object> body = Map.of(
                "title", "Study for finals (UPDATED)",
                "priority", "MEDIUM",
                "completed", false
        );

        mockMvc.perform(put("/api/tasks/" + taskId)
                .header("Authorization", token)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(body)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Study for finals (UPDATED)"))
                .andExpect(jsonPath("$.priority").value("MEDIUM"));
    }

    // TEST 5: Delete a task
    @Test
    @Order(5)
    public void testDeleteTask() throws Exception {
        mockMvc.perform(delete("/api/tasks/" + taskId)
                .header("Authorization", token))
                .andExpect(status().isNoContent());
    }
}
