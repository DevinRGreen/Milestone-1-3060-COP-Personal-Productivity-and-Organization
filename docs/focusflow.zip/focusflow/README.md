# FocusFlow — Productivity App
A centralized task management app built with Spring Boot + React.

---

## 🚀 How to Run

### Back-End (Spring Boot in IntelliJ)

1. Open IntelliJ → **File > New > Project from Existing Sources**
2. Select the `backend/` folder
3. Choose **Maven** as build tool
4. Copy ALL `.java` files into the correct package folders:
   ```
   src/main/java/com/focusflow/
   ├── FocusFlowApplication.java
   ├── model/
   │   ├── User.java
   │   └── Task.java
   ├── repository/
   │   ├── UserRepository.java
   │   └── TaskRepository.java
   ├── controller/
   │   ├── AuthController.java
   │   ├── TaskController.java
   │   └── DashboardController.java
   └── security/
       ├── JwtUtil.java
       ├── JwtAuthFilter.java
       └── SecurityConfig.java
   ```
5. Copy `application.properties` to `src/main/resources/`
6. Copy test files to `src/test/java/com/focusflow/controller/` and `src/test/java/com/focusflow/security/`
7. Click **Run** on `FocusFlowApplication.java`
8. API runs at: `http://localhost:8080`
9. H2 Console (view database): `http://localhost:8080/h2-console`

### Front-End (React)

```bash
npx create-react-app focusflow-frontend
cd focusflow-frontend
```

Copy all `.jsx`, `.js`, and `.css` files into `src/` and `src/components/`.

```bash
npm install
npm start
```

App runs at: `http://localhost:3000`

---

## 🧪 Running Tests

### JUnit (Back-End)
In IntelliJ: right-click test class → **Run**
Or via terminal: `./mvnw test`

### Jest (Front-End)
```bash
npm install --save-dev @testing-library/react @testing-library/jest-dom
npm test
```

---

## 📡 API Endpoints

| Method | Endpoint | Auth Required | Description |
|--------|----------|---------------|-------------|
| POST | /api/auth/register | No | Register new user |
| POST | /api/auth/login | No | Login, returns JWT |
| GET | /api/tasks | Yes | Get all user tasks |
| POST | /api/tasks | Yes | Create new task |
| GET | /api/tasks/{id} | Yes | Get one task |
| PUT | /api/tasks/{id} | Yes | Update task |
| DELETE | /api/tasks/{id} | Yes | Delete task |
| GET | /api/dashboard | Yes | Get summary stats |

---

## 🗂 File Structure

```
backend/
├── pom.xml                    ← Maven dependencies
├── application.properties     ← DB + JWT config
├── FocusFlowApplication.java  ← Main entry point
├── User.java                  ← User model
├── Task.java                  ← Task model
├── UserRepository.java        ← DB queries for users
├── TaskRepository.java        ← DB queries for tasks
├── AuthController.java        ← Register + Login
├── TaskController.java        ← CRUD for tasks
├── DashboardController.java   ← Summary stats
├── JwtUtil.java               ← Token generation
├── JwtAuthFilter.java         ← Request auth filter
├── SecurityConfig.java        ← Spring Security setup
├── AuthControllerTest.java    ← JUnit tests (auth)
├── TaskControllerTest.java    ← JUnit tests (CRUD)
└── SecurityTest.java          ← JUnit tests (security)

frontend/
├── App.jsx        ← Main app + routing
├── App.css        ← All styles
├── api.js         ← API call helpers
├── Login.jsx      ← Login page
├── Register.jsx   ← Register page
├── Navbar.jsx     ← Navigation bar
├── Dashboard.jsx  ← Stats overview
├── Tasks.jsx      ← Task list + CRUD
├── CreateTaskForm.jsx         ← Create/Edit form
├── LoginForm.test.jsx         ← Jest tests
├── TaskList.test.jsx          ← Jest tests
└── CreateTaskForm.test.jsx    ← Jest tests
```
